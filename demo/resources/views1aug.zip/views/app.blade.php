<!DOCTYPE html>
<html>
     
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
        <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"
        rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="{{ URL::asset('public/css/signup.css') }}" />
      <script>
  
  // When the browser is ready...
  $(function() {
     
  $.validator.addMethod("pwcheck", function(value) {
   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
       && /[a-z]/.test(value) // has a lowercase letter
       && /\d/.test(value) // has a digit
});
    // Setup form validation on the #register-form element
    $("#registration_form").validate({
    
        // Specify the validation rules
        rules: {
            username: "required",
            password: {
                required: true,
                pwcheck: true,
                minlength: 8
            },
            re_pswd: { 
                    equalTo: "#password",
                     minlength: 8
               }
        },
        
        // Specify the validation error messages
        messages: {
          
           
            username: "Please enter username",
            password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 8 characters long",
                pwcheck: "The password should be made of atleast one upper letter,one lower letter, one number. Total length should be more than 8 characters.",
            },
            re_pswd :" Enter Confirm Password Same as Password"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });
  
  </script>

    </head>
    
    <body>
		 <div class="login_text">
	 <?php if (Session::has('user_id')) {?>
		 <a href="{{ URL::asset('index.php/logout') }}">Logout</a>
	 <?php }else{?>
		  <a href="{{ URL::asset('index.php/login') }}">Login</a>
	 <?php }?>
	 </div>
		 <div class="section">
            <div class="container">
					@yield('content')
			</div>
		</div>
			
	 </body>

</html>

