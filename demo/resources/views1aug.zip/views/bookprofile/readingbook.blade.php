   @extends('profile')

@section('content')
 <p><a href="">All > Romance > Alice</a></p>
    <div class="row chapter border">
      <div class="inner-container">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 chapter-data">
          <div class="top-bar">
            <table width="100%">
              <tr>
                <td><ul>
                    <li><a href="#"><img src="{{ URL::asset('public/img/sun_ico.png') }}" class="img-responsive" /></a></li>
                    <li><a href="#"><img src="{{ URL::asset('public/img/moon_ico.png') }}" class="img-responsive" /></a></li>
                    <li style="font-size:10px" class="bold"><a href="#">T</a></li>
                    <li></li>
                    <li style="font-size:13px" class="bold"><a href="#">T</a></li>
                    <li></li>
                    <li style="font-size:16px" class="bold"><a href="#">T</a></li>
                  </ul></td>
                <td><p align="center" class="large-font">Chapter 2 XXXXXX</p></td>
                <td align="right"><div class="share-subscribe"><a href="#"> <img src="{{ URL::asset('public/img/share.png') }}" class="img-responsive"></a><a href="#"> <img src="{{ URL::asset('public/img/subscribe.png') }}" class="img-responsive"> </a></div></td>
              </tr>
            </table>
          </div>
          <div class="chapter-content">
            <ul>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
              <li>
                <div class="row">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
                    <p>Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text .Lorum ipsum is a dummy text . </p>
                  </div>
                  <div align="right" class="col-lg-1 col-md-1 col-sm-1 col-xs-1"> <img class="comment-btn" src="{{ URL::asset('public/img/comment.png') }}" /> </div>
                </div>
              </li>
            </ul>
            <div class="chapter-btn">
              <ul>
                <li><a href="#">< PREVIOUS CHAPTER</a></li>
                <li><a href="#">RETURN CHAPTER LIST</a></li>
                <li><a href="#">NEXT CHAPTER ></a></li>
              </ul>
            </div>
            <div class="chapter-btn chapter-btn-small">
              <ul>
                <li id="order"><a href="#"><img src="{{ URL::asset('public/img/basket.png') }}" class="img-responsive">Order</a></li>
                <li id="vote"><a href="#"><img src="{{ URL::asset('public/img/vote.png') }}" class="img-responsive">Vote</a></li>
                <li id="buy-book"><a href="#"><img src="{{ URL::asset('public/img/home.png') }}" class="img-responsive">Buy Book</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row comment-need-for-suffort comment-ch-9">
      <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 left border">
        <div class="comment-box">
          <p>Leave comment</p>
          <p>
            <input type="radio" name="option" />
            <img src="{{ URL::asset('public/img/good.png') }}" /> Good &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="option"/>
            <img src="{{ URL::asset('public/img/bad.png') }}" /> Bad</p>
          <textarea>
        </textarea>
          <br />
          <div class="btn" align="right">submit</div>
        </div>
        <div class="comment-div">
          <div class="comment">
            <p>Comments</p>
            <hr />
            <br>
            <div class="comment-title">
              <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
            </div>
            <div class="comment-content">
              <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
            </div>
            <hr>
          </div>
          <div class="reply">
            <div class="comment-title">
              <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
            </div>
            <div class="comment-content">
              <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
            </div>
            <hr>
          </div>
          <div class="comment">
            <div class="comment-title">
				<p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
            </div>
            <div class="comment-content">
              <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
            </div>
            <hr>
          </div>
          <div class="reply">
            <div class="comment-title">
              <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
            </div>
            <div class="comment-content">
              <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
            </div>
            <hr>
          </div>
          <div class="reply">
            <div class="comment-title">
              <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
            </div>
            <div class="comment-content">
              <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
            </div>
            <hr>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 right">
        <div class="inner-container border">
          <div class="top hot-comment">
            <p><a href="comments.html"><img src="{{ URL::asset('public/img/fire-ico.png') }}"  class="img-responsive"/>Hot Comments</a></p>
            <ul>
              <li>
                <p><a href="comments.html">Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</a></p>
              </li>
              <li>
                <p><a href="comments.html">Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</a></p>
              </li>
              <li>
                <p><a href="comments.html">Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</a></p>
              </li>
              <li>
                <p><a href="comments.html">Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</a></p>
              </li>
              <li>
                <p><a href="comments.html">Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</a></p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>

	$(document).ready(function(e) {
		$(window).resize(function(e) {
            $('.popup').fadeOut();
        });
		
		$('body').on('click',function(){
			 $('.popup').fadeOut();
		});
	
        $('.comment-btn').on('click',function(c)
		{
			
			$('.popup').fadeIn();
			var offset = $(this).offset();
			var right = offset.left;
			var w = $('.popup').width();
			$('.popup').css({
			'top': offset.top + 'px',
			'left': right - w -50+'px'
			});
			c.stopPropagation();
			
		});
		
		$('.popup').on('click',function(e)
		{
			e.stopPropagation();
		});
		
		
    });
</script>
<div class="comment-div popup">
  <div class="comment">
    <div class="comment-title">
        <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
    </div>
    <div class="comment-content">
      <p>Lorem ipsum is a dummy a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
    </div>
    <hr>
  </div>
  <div class="reply">
    <div class="comment-title">
       <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
    </div>
    <div class="comment-content">
      <p>Lorem ipsum is a dummy ttextLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
    </div>
    <hr>
  @stop
