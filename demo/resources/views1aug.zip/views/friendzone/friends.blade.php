<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="{{ URL::asset('public/css/bootstrap.min.css') }}" />
<script src="{{ URL::asset('public/js/jquery-1.11.2.min.js') }}"></script>
<link rel="stylesheet" href="{{ URL::asset('public/css/friend.css') }}" />
</head>

<body>
   <div class="main-container">
  		<div class="container">
			<div class="row">
            	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 navigation">
                	<nav>
                    	<ul class="nav">
                        	<li><a href="market-page.html">Market place</a></li>
                            <li><a href="friends-page.html">Friends zone</a></li>
                            <li><a href="space-page">Create space</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 sub-menu">
                	<div class="invite-friend">
                    	<p><a href="#">邀请朋友</a></p>
                    </div>
                    <div class="sub-menu-slide-container">
                        <ul>
                            <li class="menu1"><a href="#"><span class="arrow-active"> </span>XX圈子</a></li>
                            <div class="menu1-content">
                            	<div class="contact-details contact-user-book">
                                	<p>Calvin</p>
                                    <p>评论了作品《XXXXXXXXXX》</p>
                                    <p>更新了作品《XXXXXXXXXX》</p>
                                </div>
                                <div class="contact-details contact-user-book">
                                	<p>Marvin</p>
                                    <p>评论了作品《XXXXXXXXXX》</p>
                                    <p>更新了作品《XXXXXXXXXX》</p>
                                </div>
                                <div class="contact-details ">
                                	<p>Tony</p>
                                    <p>评论了作品《XXXXXXXXXX》</p>
                                    
                                </div>
                                <div class="contact-details ">
                                	<p>Lynn</p>
                                    <p>评论了作品《XXXXXXXXXX》</p>
                                    
                                </div>
                                <div class="contact-details ">
                                	<p>David</p>
                                    <p>评论了作品《XXXXXXXXXX》</p>
                                   
                                </div>
                            </div>
                            <li class="menu2"><a href="#"><span class="arrow"> </span>XX圈子</a></li>
                            <li class="menu3"><a href="#"><span class="arrow"> </span>XX圈子</a></li>
                            <li class="menu4"><a href="#"><span class="arrow"> </span>XX圈子</a></li>
                            
                        </ul>
                    </div>
                    <div class="footer-option-parent">
                        <div class="row footer-option">
                            <div class="col-lg-6 col-md-6 col-sm-6 left footer-active">
                                <p><a href="#">朋友</a></p>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 right">
                                <p><a href="#">对话</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7 content">
                	
                    	<div class="row dp">
                        	<a href="#"><img src="{{ URL::asset('public/img/dp.png') }}" class="img-responsive" /></a>
                        </div>
                        <div class="row name">
                        	<p>Calvin (作家)</p>
                        </div>
                        <div class="row icons">
                        	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                            	<a href="gift-tab2.html"><img src="{{ URL::asset('public/img/n.png') }}" class="img-responsive" /></a>
                                <p>个人主页</p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 ">
                            	<a href="conversation.html"><img src="{{ URL::asset('public/img/hi.png') }}" class="img-responsive" /></a>
                                <p>打招呼发</p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 ">
                            	<a href="#"><img src="{{ URL::asset('public/img/env.png') }}" class="img-responsive" /></a>
                                <p>发邮</p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 ">
                            	<a href="gift-page.html"><img src="{{ URL::asset('public/img/heart.png') }}" class="img-responsive" /></a>
                                <p>送礼物</p>
                            </div>
                        </div>
                        <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">昵称：</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value"> Calvin</div>
                        </div>
                         <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">备注：</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value"> <a href="">Edit</a></div>
                        </div>
                         <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">NewbBay账号</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value"> xxxxxxxxx</div>
                        </div>
                         <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">Email:</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value"> xxxxx@xxxx.xxx</div>
                        </div>
                        <br />
                        <br />
                        <br />
                        
                           <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">阅读记录：</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value"> 《XXXXXXXXXXXX》</div>
                        </div>
                         <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">最新评论：</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value">《xxxxxxxxx》第xx章：“xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,x<br />这一段写的真是太赞了！</div>
                        </div>
                         <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 title">最近更新：</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 value">《xxxxxxxxxxx》更新至第xx章</div>
                        </div>
                        
                        <div class="row content-button">
                        	<div class="button-area">
								<a href="#">Start a Conversation</a>
                            </div>
                        </div>
                         
                       
                   
                </div>
            </div>
        </div>
   </div>
</body>
</html>
