   @extends('profile')

@section('content')
  <p><a href="">All &gt; Romance &gt; Alice &gt; Chapter 2 &gt; Hot comments</a></p>
    <div class="row chapter border">
      <div class="inner-container" style="
    width: 80%;
    margin: auto;
">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 chapter-data">
          <div class="comment-div">
            <div class="comment">
              <p>Comments</p>
              <hr>
              <br>
              <div class="comment-title">
              <p><span class="name">Karen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span> <span class="like-dislike"> <a href="#"><img src="{{ URL::asset('public/img/star.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/reply-ico.png') }}"></a> <a href="#"><img src="{{ URL::asset('public/img/thumbs-up.png') }}"></a> <span>0</span> <a href="#"><img src="{{ URL::asset('public/img/dislike.png') }}"> </a><span>0</span> </span> </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            <div class="reply">
              <div class="comment-title">
                <p><span class="name">Wen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span>  </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            <div class="reply">
              <div class="comment-title">
                <p><span class="name">Wen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span>  </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            <div class="reply">
              <div class="comment-title">
                <p><span class="name">Wen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span>  </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            <div class="reply">
              <div class="comment-title">
                <p><span class="name">Wen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span>  </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            <div class="reply">
              <div class="comment-title">
                <p><span class="name">Wen</span><span class="time">Time: 5/13/2015 &nbsp;&nbsp;&nbsp; 20:00:00</span>  </p>
              </div>
              <div class="comment-content">
                <p>Lorem ipsum is a dummy text Lorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy textLorem ipsum is a dummy text</p>
              </div>
              <hr>
            </div>
            
            
          </div>
        </div>
      </div>
    </div>
  @stop
