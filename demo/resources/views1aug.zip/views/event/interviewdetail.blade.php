 @extends('eventlayout')

@section('content')
 <div id="page-content-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-9">
                            <a href="{{ URL::asset('index.php/interview') }}"><h4>Back to interview list</h4></a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-md-12" style="border:1px solid yellow">
                                    <h1 class="text-center">Interview with Colletz Cortaz</h1>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisici elit,
                                        <br>sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                                        <br>Ut enim ad minim veniam, quis nostrud</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /#page-content-wrapper -->
@stop
