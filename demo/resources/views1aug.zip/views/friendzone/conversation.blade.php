<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="{{ URL::asset('public/css/bootstrap.min.css') }}" />
<script src="{{ URL::asset('public/js/jquery-1.11.2.min.js') }}"></script>
<link rel="stylesheet" href="{{ URL::asset('public/css/friend.css') }}" />
</head>

<body>
   <div class="main-container gift-tab1 gift-tab-2 gift-tab-3 conversation">
  		<div class="container">
			<div class="row">
            	<div class="close1"><img src="images/close.png" /></div>
            	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 navigation">
                	<nav>
                    	<ul class="nav">
                        	<li><a href="market-page.html">Market place</a></li>
                            <li><a href="friends-page.html">Friends zone</a></li>
                            <li><a href="space-page">Create space</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 sub-menu">
                	
                    <div class="sub-menu-slide-container">
                        <ul>
                            <div class="menu1-content">
                            	<div class="contact-details contact-user-book">
                                	<p>Calvin</p>
                                    
                                </div>
                                <div class="contact-details contact-user-book">
                                	<p>Marvin</p>
                                   
                                </div>
                                <div class="contact-details ">
                                	<p>Tony</p>
                                    
                                    
                                </div>
                                <div class="contact-details ">
                                	<p>Lynn</p>
                                    
                                </div>
                                <div class="contact-details ">
                                	<p>David</p>
                                  
                                   
                                </div>
                            </div>
                        </ul>
                    </div>
                    <div class="footer-option-parent">
                        <div class="row footer-option">
                            <div class="col-lg-6 col-md-6 col-sm-6 left">
                                <p><a href="#">朋友</a></p>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 right  footer-active">
                                <p><a href="#">对话</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7 content">
                		
                    	
                        
                       	
                        <div class="row comments-section">
                        	<div class="row me">
                            	<div class="comment-data">
                                	<p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
                                </div>
                            </div>
                            <div class="row you">
                            	<div class="comment-data">
                                	<p>OK</p>
                                </div>
                            </div>
                            <br />
                            <div class="row me">
                            	<div class="comment-data">
                                	<p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
                                </div>
                            </div>
                            <div class="row you">
                            	<div class="comment-data">
                                	<p>No, I don't think so</p>
                                </div>
                            </div>
                        </div>
                        <div class="row writer">
                        	<textarea draggable="false">xxxxxxxxxxxxxxxx</textarea>
                            <div class="writer-submit">
                            	发送
                            </div>
                        </div>                        
                         
                </div>
            </div>
        </div>
   </div>
</body>
</html>
